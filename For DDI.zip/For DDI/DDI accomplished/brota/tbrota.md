rm(list=ls())
dev.off()
setwd('/Users/liyixian1990/Desktop/brota')
a<-read.csv('t41he.csv',row.names=1)
library(Boruta)
set.seed(100)
boruta_output <- Boruta(He ~ ., data=na.omit(a), pValue = 0.05, mcAdj = TRUE, doTrace = 2)
summary(boruta_output)
importance <- boruta_output$ImpHistory  

plot(boruta_output, las = 2, xlab = '', main = 'Variable Importance',family = "serif")
boruta_df <- attStats(boruta_output)
boruta_df