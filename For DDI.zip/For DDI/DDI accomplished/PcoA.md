setwd('/Users/liyixian1990/Desktop/DDI')#和UPGMA颜色对应
library(vegan)
trapa<-read.csv('trapapcoa.csv',header=T,row.names=1)
dist<-vegdist(trapa,method='jaccard')
library(ape)
trapa.pcoa<-pcoa(dist,correction = 'none')

pc1<-trapa.pcoa$vectors[,1]
pc2<-trapa.pcoa$vectors[,2]
dataframe<- data.frame(pc1,pc2)
grou<-read.csv('trapagroup.csv',header=T)

dataframe2<-data.frame(dataframe,grou)

trapa.pcoa
sum_eig <- sum(trapa.pcoa$values$Eigenvalues)#欧式距离用，Jaccrad也可以用，但是bray不可以用，先提取个总的

library(ggplot2)

xlab<-round(trapa.pcoa$values$Eigenvalues[1]/sum_eig*100,2)
ylab<-round(trapa.pcoa$values$Eigenvalues[2]/sum_eig*100,2)

#xlab<-round(vela.pcoa$values$Rel_corr_eig[1]*100,2)#bray距离两个轴用这个
#ylab<-round(vela.pcoa$values$Rel_corr_eig[2]*100,2)


dataframe2$group<-ifelse(dataframe2$group<1,'Group A','Group B')

ggplot(data=dataframe2,aes(x=pc1,y=pc2,color=group,shape=group))+
  geom_point(size=3)+
  scale_shape_manual(values = c(15, 17))+
  theme_bw()+
  theme(panel.grid = element_blank())+
  geom_vline(xintercept = 0,lty="dashed")+
  geom_hline(yintercept = 0,lty="dashed")+
  labs(x=paste0("PCoA1 ",xlab,"%"),
       y=paste0("PCoA2 ",ylab,"%"))+
  stat_ellipse(data=dataframe2,level=0.95,
               geom = "polygon",
               aes(fill=group),
               alpha=0.1)+
  #scale_fill_manual(values = c('salmon',"navy"))+
  scale_color_manual(values = c( '#925E9FFF','#0099B4FF'))+
  theme(rect = element_rect(size=1.5))

dev.off()
rm(list=ls())