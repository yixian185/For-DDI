setwd('/Users/liyixian1990/Desktop/DDI')
a<-read.csv('theslope.csv',row.names=1)
library(ggplot2)
library(ggpubr)
ggplot(a,aes(x=Slope,y=He))+
  geom_point(size=5,color='#3C5488FF')+
  geom_smooth(method = "lm", colour = "#DC0000FF", alpha = 0.4)+
  stat_cor(data=a, method = "spearman",digits = 2,label.x=0.4,label.y=0.3,size=5,family='Arial')+
  theme_classic()+
  theme(axis.text.x = element_text(face = "bold",colour = "black", size = 11), 
         axis.text.y = element_text(face = "bold", size = 11, colour = "black"),
        axis.line=element_line(color='black',size=1))

dev.off()